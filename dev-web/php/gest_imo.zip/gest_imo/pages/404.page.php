<?php partial('head.php'); ?>

<body class="d-flex justify-content-center align-items-center bg-light" style="height: 100dvh;">
    <div class="d-flex flex-column gap-3 bg-white p-5 shadow-sm rounded-1 align-items-center w-50">
        <h1>404</h1>
        <p>Page not found</p>
        <a href="/">Back to home</a>
    </div>

</html>