<?php

return [
    '/' => controller("objects/index.php"),
    '/objects' => controller("objects/index.php"),
    '/objects/create' => controller("objects/create.php"),
    '/objects/edit' => controller("objects/edit.php"),
    '/objects/show' => controller("objects/show.php"),
];
