<?php

return [
    'string' => "{attr} n'est pas une chaîne de caractères valide",
    'email' => "{attr} n'est pas un email valide",
];
